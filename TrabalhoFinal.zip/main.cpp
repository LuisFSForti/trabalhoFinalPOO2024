//////////////////////// ALUNOS ///////////////////////////////
//  Eduardo Briosos Luceiro     - 14607621                   //
//  Heloísa Pazeti              - 14577991                   //
//  Luis Filipe Silva Forti     - 14592348                   //
///////////////////////////////////////////////////////////////

#include "Controller/controller.hpp"

int main()
{
    Controller c;
    c.StartGame();
    return 0;
}
