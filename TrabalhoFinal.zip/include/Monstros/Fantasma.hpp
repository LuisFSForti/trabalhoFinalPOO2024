#ifndef Fantasma_HPP
#define Fantasma_HPP

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>

#include "../Player/Personagem.hpp"

//Objetivo da classe: baixíssima vida, altíssima esquiva, dano mágico baixo
class Fantasma : public Personagem
{
    private:
        void Atacar(std::vector<Personagem*> alvos); //Golpeia um inimigo
        void CausarDano(Personagem* alvo); //Dano mágico médio
        void EfeitoAuxiliar(std::vector<Personagem*> alvos); //Amedronta os inimigos

        void ImprimirDados(std::ostream& out) const;

    public:
        Fantasma(std::string id = "");
};



#endif