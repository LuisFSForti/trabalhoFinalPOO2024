#include "Monstros/Fada.hpp"

//Ataca múltiplos inimigos
void Fada::Atacar(std::vector<Personagem*> alvos)
{
    //Para cada ataque
    for(int i = 0; i < this->_qtdAtaques + this->_modificadorQuantidadeAtaques; i++) //Ataca múltiplas vezes
    {
        int posAlvo;
        do
        {
            //Sem prioridade de alvo
            posAlvo = rand() % 4;
        } while (alvos.at(posAlvo)->GetVida() <= 0); //Até achar um alvo válido

        //Pega o alvo atual
        Personagem* alvo = alvos.at(posAlvo);

        //Verifica se o ataque acerta
        int dado = rand()%20;
        int ataque = dado + this->_precisao + this->_buffPrecisao;
        int esquiva = (alvo->GetEsquiva() + alvo->GetBuffEsquiva()) * alvo->GetModificadorEsquiva() + 10;

        std::cout << "Ataque: " << dado << " + " << this->_precisao << " + " << this->_buffPrecisao << " = " << ataque << std::endl;
        std::cout << "Esquiva ("<< Nomes[posAlvo] << "): (" << alvo->GetEsquiva() << " + " << alvo->GetBuffEsquiva() << ") *" << alvo->GetModificadorEsquiva() << " + 10 = " << esquiva << std::endl;

        if(ataque >= esquiva)
        {
            //Se sim, calcula o dano
            this->CausarDano(alvo);
        }
    }
}
    
//Dano mágico médio com alta chance de crítico
void Fada::CausarDano(Personagem* alvo)
{
    //Calcula se é crítico
    bool critico = rand() % 20 + _sorte >= 20;

    //Calcula o dano
    //(1 + critico) = 1 ou 2
    int dano = (rand() % 6 + this->_arma + this->_buffArma) * (1 + critico);

    if(critico)
        std::cout << "Crítico!!!!" << std::endl;
    std::cout << "Acertou por " << dano << " de dano mágico!" << std::endl << std::endl;

    //Alerta o alvo que ele recebeu dano mágico e quanto
    alvo->ReceberDanoMagico(dano);
}
    
//Paralisa um inimigo
void Fada::EfeitoAuxiliar(std::vector<Personagem*> alvos)
{
    //Define que já usou sua habilidade auxiliar
    this->_mana = false;

    int posAlvo;
    do
    {
        //Sem prioridade de alvo
        posAlvo = rand() % 4;
    } while (alvos.at(posAlvo)->GetVida() <= 0); //Até achar um alvo válido

    //Paralisa o alvo
    alvos.at(posAlvo)->AplicarStatus(paralisado);
}

void Fada::ImprimirDados(std::ostream& out) const
{
    out << "A fada docemente sorri enquanto te ataca,\nacho que um de vocês caiu desacordado.\n";
    out << "==============================================\n";
}

Fada::Fada(std::string id)
{
    //Inicializa o aleatorizador
    srand(time(NULL));

    this->_vidaMaxima = 50;
    this->_vida = this->_vidaMaxima;
    this->_armadura = 0;
    this->_esquiva = 6;

    this->_precisao = 10;
    this->_sorte = 4;
    this->_arma = 4;
    this->_qtdAtaques = 3;

    this->_ferramenta = 0;
    this->_armaduraMagica = 10; //Resistência mágica

    this->_buffVida = 0;
    this->_buffArmadura = 0;
    this->_buffArmaduraMagica = 0;
    this->_buffEsquiva = 0;
    this->_buffPrecisao = 0;
    this->_buffSorte = 0;
    this->_buffArma = 0;
    this->_buffFerramenta = 0;

    this->_modificadorEsquiva = 1;
    this->_modificadorDefesa = 0;
    this->_modificadorQuantidadeAtaques = 0;
    this->_status = estavel;
    _mana = true;

    _idFile = id;
}